<?php
define('APP_ID', '110309');
define('APP_KEY', 'c04c876469541c9cb7d7');
define('APP_SECRET', '8138b5f50162bba56827');
?>